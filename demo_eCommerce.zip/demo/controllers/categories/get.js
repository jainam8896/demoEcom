const Category = require("../../models/Category");

//display category Root
const getCategory = async (req, res) => {
  try {
    const { id } = req.params;
    const category = await Category.findById(id);
    if (!category) {
      return res.status(404).json("Category not found!");
    }
    res.json(category);
  } catch (error) {
    res.json(error);
  }
};

module.exports = getCategory;
