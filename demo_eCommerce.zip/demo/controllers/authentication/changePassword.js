const User = require("../../models/User");
const bcrypt = require("bcrypt");

const changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const user = await User.findById(req.user._id);
    const match = bcrypt.compareSync(currentPassword, user.password);
    if (!match) {
      // return res
      //   .status(401)
      //   .send({ status: "failed", message: "Invalid Current Password" });
      throw new CustomError("Invalid Current Password", 401);
    }
    const hasPassword = bcrypt.hashSync(newPassword, 10);
    user.password = hasPassword;
    await user.save();
    return res.status(200).send({
      status: "success",
      message: "Password Changed Successfully",
    });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .send({ status: "error", message: "Internal Server Error" });
  }
};

module.exports = changePassword;
