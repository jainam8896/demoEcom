const mongoose = require('mongoose')
const autopopulate = require('mongoose-autopopulate')

const scehma = new mongoose.Schema({
    productName:{
        type: String,
        required: true
    },
    productDescription:{
        type: String,
        required: true
    },
    productPrice:{
        type: Number,
        required: true
    },
    productQty: {
        type: Number,
        required: true
    },
    productimage: {
        type: String,
        required: true
      },
    categoryId:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'Category',
        autopopulate:true
    }
},{
    timestamps: true
})

scehma.plugin(autopopulate)

const Product = mongoose.model('product',scehma)
module.exports = Product