const Product = require("../../models/Product");

//Display Product
const listProduct = async (req, res) => {
  try {
    const product = await Product.find({});
    if (!product) {
      return res.status(404).json("Product not found!");
    }
    res.json(product);
  } catch (error) {
    res.json(error);
  }
};

module.exports = listProduct;
