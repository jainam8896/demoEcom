const Product = require("../../models/Product");

//Display Product By Id
const getProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const product = await Product.findById(id);
    if (!product) {
      return res.status(404).json("Product not found!");
    }
    res.json(product);
  } catch (error) {
    res.json(error);
  }
};

module.exports = getProduct;
