const Category = require("../../models/Category");
const User = require("../../models/User")
const pagination = require("../../helper/pagination");

//Display category
// const listCategory = async (req, res) => {
//   try {
//     const category = await Category.find({});
//     if (!category) {
//       return res.status(404).json("Category not found!");
//     }
//     res.json(category);
//   } catch (error) {
//     res.json(error);
//   }
// };

const listCategory = async (req, res) => {
  try {
    const params = req.body;

    const category = await pagination(params, Category);
    //const category = await pagination(params, User);
    res.json(category)
  } catch (error) {
    console.log("Inside Cathg", error);
    res.status(500).json(error);
  }
};

module.exports = listCategory;
