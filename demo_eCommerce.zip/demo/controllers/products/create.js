const Product = require("../../models/Product");

//Create Product //  (req, res, next)
const createProduct = async (req, res) => {
  const { productName, productDescription, productPrice, productQty } =
    req.body;
  const product = await Product.findOne({ productName: productName });
  if (product) {
    return res.send({
      status: "failed",
      message: "Product Already Exists.....Please Enter Different Product",
    });
  }
  const newProduct = new Product({
    productName: productName,
    productDescription: productDescription,
    productPrice: productPrice,
    productQty: productQty,
    productimage: req.file.filename
  });
  await newProduct.save();
  res
    .status(200)
    .send({ status: "success", message: "Product Added Successfully" });
};

module.exports = createProduct;
