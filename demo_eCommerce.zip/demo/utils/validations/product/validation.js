const { body } = require("express-validator");

const productValidator = [
  body("productName").notEmpty().withMessage("Product is required"),
  body("productDescription").notEmpty().withMessage("Product Description is required"),
  body("productPrice").isInt().withMessage("Product Price Is Required"),
  body("productQty").isInt().withMessage("Product Price Is Required"),
  body("productimage")
    .custom((value, { req }) => {
      if (
        req.file.mimetype === "image/jpg" ||
        req.file.mimetype === "image/jpeg" ||
        req.file.mimetype === "image/png"
      ) {
        return true;
      } else {
        return false;
      }
    })
    .withMessage("Please upload jpg, png, or jpeg file"),
  body("categoryId").notEmpty().withMessage("Category is required"),
];

module.exports = {productValidator}